import PlaceholderPage from "../components/PlaceholderPage";

export default function AssessmentsPage() {
  return (
    <PlaceholderPage
      title="Assessments"
      description="Assessment schedules and results will appear here."
    />
  );
}